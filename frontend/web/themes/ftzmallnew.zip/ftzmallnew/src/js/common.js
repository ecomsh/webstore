$(function () {
    $("[data-toggle='popover']").popover();
    $(".alert-btn").click(function () {
        alert("我是alert出来的");
    });
});
        //
