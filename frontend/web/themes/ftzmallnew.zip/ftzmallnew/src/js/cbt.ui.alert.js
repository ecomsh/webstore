jQuery(function () {

    $('#myModal').modal('show');
    $('#modal-content-title').html('尊敬的xxx');
    $('#modal-content-body').html('您好，已经成功加入购物车');

});



