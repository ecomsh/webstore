$(".header-search").focus(function(){
	$(this).attr('placeholder','');
})