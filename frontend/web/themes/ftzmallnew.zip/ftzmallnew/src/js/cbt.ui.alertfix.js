jQuery(function () {
    jQuery("#w0-address_success-0").slideUp("slow");   
    jQuery("#w0-address_error-0").slideUp("slow");
    
    
    jQuery("#w1-realname_success-0").slideUp("slow");
    jQuery("#w1-realname_error-0").slideUp("slow");
    
});



